const fondo = document.getElementById('fondo')
let es = 0;

function cambiar3(){
    if(es == 0){
        fondo.src = './img/Yoshi.jpg'
    } 
    Texto.innerText = 'Tercera imagen'
}
function cambiar(){
    if(es == 0){
        fondo.src = './img/Yoshi G.jpg'
    }
    Texto.innerText = 'Primera imagen'
}
function cambiar2(){
    if(es == 0){
        fondo.src = './img/Mario furro.jpg'
    }
    Texto.innerText = 'Segunda imagen'
}
function cambiar4(){
    if(es == 0){
        fondo.src = './img/Kiddy.jpg'
    }
    Texto.innerText = 'Cuarta imagen'
}

/* const Texto = document.getElementById('Texto')

function trt(){
    Texto.innerText = 'Primera imagen'
}

function trt3(){
    Texto.innerText = 'Tercera imagen'
}
function trt2(){
    Texto.innerText = 'Segunda imagen'
}
function trt4(){
    Texto.innerText = 'Cuarta imagen'
} */